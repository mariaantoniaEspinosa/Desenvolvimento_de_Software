package com.example.firstapp;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    private Label lblMensagem;

    @FXML
    private TextField txtNome;

    @FXML
    protected void exibirMensagem() {
        String nome = txtNome.getText();

        if (nome.equals("")) {
            lblMensagem.setText("Digite seu nome....");
        } else {
            lblMensagem.setText("Nome: " + nome + "\n");
        }
    }

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}