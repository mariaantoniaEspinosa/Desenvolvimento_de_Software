/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;


import beans.Produtos;
import conexao.conexao;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author manto
 */
public class ProdutosDAO {
    private conexao c;
    private Connection conn;
    
    public ProdutosDAO(){
        this.c = new conexao();
        this.conn = this.c.getConexao();
    }
    
    public void inserir (Produtos p){
            String sql = "INSERT INTO Produtos (nome, preco, quantidade) VALUES (?,?,?)";        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());     
            stmt.setDouble(2, p.getPreco());
            stmt.setInt(3, p.getQuantidade());
            stmt.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao inserir Produto:" + ex.getMessage());
        }
    }
    public Produtos getProdutos(int id){
        String sql = "SELECT * FROM Produtos WHERE id = ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Produtos p = new Produtos();
            rs.first();
            p.setId(id);
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getDouble("Preço"));
            p.setQuantidade(rs.getInt("Quantidade"));
            return p;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar Categoria: " + ex.getMessage());
            return null;
        }
    }
    
    public void editar(Produtos p){
        try{
            String sql = "UPDATE Produtos set nome=?, preco=?, quantidade=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setDouble(2, p.getPreco());
            stmt.setInt(3, p.getQuantidade());
            stmt.setInt(4, p.getId());
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao atualizar Produto: " + ex.getMessage());
        }
    }
    
    public void excluir(int id){
        try{
            String sql = "delete from Produto WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao excluir Produto: " + ex.getMessage());
        }
    }   

    public List<Produtos> pesquisar(String texto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Produtos> getProdutos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
