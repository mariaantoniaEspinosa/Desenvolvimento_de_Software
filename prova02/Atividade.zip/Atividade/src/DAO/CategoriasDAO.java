/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Categorias;
import conexao.conexao;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author manto
 */
public class CategoriasDAO {
    private conexao c;
    private Connection conn;
    
    public CategoriasDAO(){
        this.c = new conexao();
        this.conn = this.c.getConexao();
    }
    
        public List<Categorias> getCategoria() {
        String sql = "SELECT * FROM categoria";
        List<Categorias> listaCategoria = new ArrayList<>();

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Categorias c = new Categorias();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                listaCategoria.add(c);
            }

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar Categoria: " + ex.getMessage());
        }
        return listaCategoria;
    }

    
    public void inserir (Categorias c){
            String sql = "INSERT INTO Categorias (nome) VALUES (?)";        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, c.getNome());
         
            stmt.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao inserir Categoria:" + ex.getMessage());
        }
    }
    public Categorias getCategorias(int id){
        String sql = "SELECT * FROM Categorias WHERE id = ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Categorias c = new Categorias();
            rs.first();
            c.setId(id);
            c.setNome(rs.getString("nome"));
            return c;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar Categoria: " + ex.getMessage());
            return null;
        }
    }
    
    public void editar(Categorias c){
        try{
            String sql = "UPDATE Categorias set nome=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.setInt(2, c.getId());
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao atualizar Categoria: " + ex.getMessage());
        }
    }
    
    public void excluir(int id){
        try{
            String sql = "delete from Categorias WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao excluir Categoria: " + ex.getMessage());
        }
    }   
}
