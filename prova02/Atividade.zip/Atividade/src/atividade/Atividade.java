/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade;

import DAO.CategoriasDAO;
import DAO.ProdutosDAO;
import beans.Categorias;
import beans.Produtos;
import conexao.conexao;

/**
 *
 * @author manto
 */
public class Atividade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        conexao c = new conexao();
        c.getConexao();
        
        Categorias cat  = new Categorias();
        CategoriasDAO cDAO = new CategoriasDAO();
        cDAO.inserir(cat);
        
        Produtos p = new Produtos();
        ProdutosDAO pDAO = new ProdutosDAO();
        pDAO.inserir(p);
    }
    
}
