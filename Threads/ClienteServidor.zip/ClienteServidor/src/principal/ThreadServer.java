/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import beans.Pessoa;
import dao.PessoaDAO;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author laboratorio
 */
public class ThreadServer extends Thread{
    private Socket clienteSocket;
    
    public ThreadServer(Socket clienteSocket){
        this.clienteSocket = clienteSocket;
    }
    
    @Override
    public void run() {
        try {
            ObjectOutputStream out = new ObjectOutputStream(clienteSocket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(clienteSocket.getInputStream());

            // 1. Recebe o objeto Pessoa enviado pelo cliente
            Pessoa p = (Pessoa) in.readObject();
            System.out.println("Pessoa recebida para cadastro: " + p.getNome());

            // 2. Tenta inserir no banco e devolve a resposta ao cliente
            try {
                PessoaDAO pdao = new PessoaDAO();
                pdao.inserir(p);
                out.writeObject("sucesso");
            } catch (Exception ex) {
                out.writeObject("erro: " + ex.getMessage());
            }

            out.flush();
            clienteSocket.close();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Erro na comunicação com o cliente: " + ex.getMessage());
        }
    }
}
