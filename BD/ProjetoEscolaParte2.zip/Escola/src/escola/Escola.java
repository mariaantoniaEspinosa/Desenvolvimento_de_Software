/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package escola;

import DAO.alunosDAO;
import DAO.professorDAO;
import beans.alunos;
import beans.professor;
import conexao.conexao;

/**
 *
 * @author manto
 */
public class Escola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        conexao c = new conexao();
        c.getConexao();
        
        alunos a = new alunos();
        alunosDAO aDAO = new alunosDAO();
        aDAO.inserir(a);
        
        professor p = new professor();
        professorDAO pDAO = new professorDAO();
        pDAO.inserir(p);
        
    }
    
}
