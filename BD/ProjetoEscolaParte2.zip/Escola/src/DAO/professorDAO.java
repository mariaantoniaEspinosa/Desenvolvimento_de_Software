/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.alunos;
import beans.professor;
import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author laboratorio
 */
public class professorDAO {
    private conexao c;
    private Connection conn;
    
    public professorDAO(){
        this.c = new conexao();
        this.conn = this.c.getConexao();
    }
    public void inserir (professor p){
            String sql = "INSERT INTO professor (nome, idade, disciplina) VALUES (?,?,?)";        
            try {
               PreparedStatement stmt = this.conn.prepareStatement(sql);
               stmt.setString(1, p.getNome());
               stmt.setInt(2, p.getIdade());
               stmt.setString(3, p.getDisciplina());

               stmt.execute();
           } catch (SQLException ex){
               System.out.println("Erro ao inserir professor:" + ex.getMessage());
           }
       }   
   
    public professor getProfessor(int id){
        String sql = "SELECT * FROM professor WHERE id = ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            professor p = new professor();
            rs.first();
            p.setId(id);
            p.setNome(rs.getString("nome"));
            p.setIdade(rs.getInt("idade"));
            p.setDisciplina(rs.getString("disciplina"));
            return p;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar professor: " + ex.getMessage());
            return null;
        }
    }
    
    public void editar(professor p){
        try{
            String sql = "UPDATE professor set nome=?, idade=?, disciplina=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setInt(2, p.getIdade());
            stmt.setString(3, p.getDisciplina());
            stmt.setInt(4, p.getId());
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao atualizar professor: " + ex.getMessage());
        }
    }
    
    public void excluir(int id){
        try{
            String sql = "delete from professor WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao excluir professor: " + ex.getMessage());
        }
    }
}
