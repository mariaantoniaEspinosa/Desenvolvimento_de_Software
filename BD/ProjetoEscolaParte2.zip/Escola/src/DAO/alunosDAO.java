/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.alunos;
import conexao.conexao;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author manto
 */
public class alunosDAO {
    private conexao c;
    private Connection conn;
    
    public alunosDAO(){
        this.c = new conexao();
        this.conn = this.c.getConexao();
    }
    
    public void inserir (alunos a){
            String sql = "INSERT INTO alunos (nome, idade, disciplina) VALUES (?,?,?)";        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, a.getNome());
            stmt.setInt(2, a.getIdade());
            stmt.setString(3, a.getDisciplina());
            
            stmt.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao inserir aluno:" + ex.getMessage());
        }
    }
    public alunos getAlunos(int id){
        String sql = "SELECT * FROM alunos WHERE id = ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            alunos a = new alunos();
            rs.first();
            a.setId(id);
            a.setNome(rs.getString("nome"));
            a.setIdade(rs.getInt("idade"));
            a.setDisciplina(rs.getString("disciplina"));
            return a;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar aluno: " + ex.getMessage());
            return null;
        }
    }
    
    public void editar(alunos a){
        try{
            String sql = "UPDATE alunos set nome=?, idade=?, disciplina=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, a.getNome());
            stmt.setInt(2, a.getIdade());
            stmt.setString(3, a.getDisciplina());
            stmt.setInt(4, a.getId());
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao atualizar aluno: " + ex.getMessage());
        }
    }
    
    public void excluir(int id){
        try{
            String sql = "delete from alunos WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("Erro ao excluir alunos: " + ex.getMessage());
        }
    }
}
