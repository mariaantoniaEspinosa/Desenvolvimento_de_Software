/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.alunos;
import conexao.conexao;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author manto
 */
public class alunosDAO {
    private conexao c;
    private Connection conn;
    
    public alunosDAO(){
        this.c = new conexao();
        this.conn = this.c.getConexao();
    }
    
    public void inserir (alunos a){
String sql = "INSERT INTO aluno (nome, idade, disciplina) VALUES (?,?,?)";        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, a.getNome());
            stmt.setInt(2, a.getIdade());
            stmt.setString(3, a.getDisciplina());
            
            stmt.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao inserir aluno:" + ex.getMessage());
        }
    }
}
