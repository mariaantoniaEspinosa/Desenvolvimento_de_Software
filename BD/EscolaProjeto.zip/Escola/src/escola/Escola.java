/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package escola;

import DAO.alunosDAO;
import beans.alunos;
import conexao.conexao;

/**
 *
 * @author manto
 */
public class Escola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        conexao c = new conexao();
        c.getConexao();
        
        alunos a = new alunos();
        a.setNome("Maria Antonia");
        a.setIdade(20);
        a.setDisciplina("Desenvolvimento de software");
        
        alunosDAO aDAO = new alunosDAO();
        aDAO.inserir(a);
        
    }
    
}
